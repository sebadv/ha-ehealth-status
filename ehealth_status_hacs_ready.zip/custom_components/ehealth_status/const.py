DOMAIN = "ehealth_status"
API_URL = "https://status.ehealth.fgov.be/nl/api/components/prod"
